# workout_app

> Una app Flutter per la gestione degli allenamenti con autenticazione utente e sistema di recensioni.

[![Flutter](https://img.shields.io/badge/Flutter-3.10-blue)](https://flutter.dev)  
[![Dart](https://img.shields.io/badge/Dart-3.1-green)](https://dart.dev)  

## Indice

- [Descrizione](#descrizione)  
- [Funzionalità](#funzionalità)  
- [Tecnologie](#tecnologie)  
- [Requisiti](#requisiti)    

## Descrizione

`workout_app` è un’applicazione mobile sviluppata in Flutter che permette agli utenti di:
- Creare un profilo e autenticarsi tramite Firebase Auth  
- Registrare e visualizzare sessioni di allenamento  
- Salvare dati in locale con `shared_preferences` per ottimizzare l’esperienza offline  

## Funzionalità

- **Autenticazione**: registrazione e login con email/password  
- **Gestione allenamenti**: CRUD di workout  
- **Recensioni**: commenti e rating per ciascun allenamento  
- **Persistenza**: sincronizzazione real‑time con Firestore  
- **Offline support**: cache locale dei dati più recenti  

## Tecnologie

- **Flutter 3.x** & **Dart 3.x**  
- **State Management**: [Provider](https://pub.dev/packages/provider)  
- **Firebase**:  
  - `firebase_core`  
  - `firebase_auth`  
  - `cloud_firestore`  
- **Local Storage**: `shared_preferences`  

## Requisiti

- Flutter SDK ≥ 3.1  
- Dart SDK ≥ 3.1  
- Account Firebase con progetto configurato  

